# pawn-stdlib

The Pawn Standard Library Package, not including any files related to SA:MP - designed for the [sampctl package management system](http://sampctl.com).

## Why?

The package management system built into the `sampctl` tool is based on GitHub (Similar to that of the Go language) so it simplifies the process to have the standard library stored here on GitHub too. This means there doesn't need to be any special-case code written for the standard library, it can just be a package like all others.
